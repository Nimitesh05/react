export function Contact(){

    return(
        <div>
            <h3>contact details:</h3>
            <p>+91 965782929</p>
        </div>
    );
}