import logo from './logo.svg';
import './App.css';

import {UserFetchData} from './UserFetchData'
function App() {
  return (
     <div>
    <UserFetchData></UserFetchData>
     </div>
  );
}

export default App;
